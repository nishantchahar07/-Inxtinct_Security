import OpenAI from 'openai';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
const model = process.env.OPENAI_MODEL || 'gpt-4o-mini';

const SYSTEM_PROMPT = `You must decide ONLY which tool to call by returning a pure JSON object with no explanation. 
Example schema:
{
  "tool": "weather",
  "city": "San Francisco"
}
OR
{
  "tool": "database",
  "query": "count employees joined last month"
}
Return ONLY JSON. No English sentence.`;

export async function getRoutingInstructions(userMessage: string): Promise<string> {
  const completion = await openai.chat.completions.create({
    model,
    messages: [
      { role: 'system', content: SYSTEM_PROMPT },
      { role: 'user', content: userMessage },
    ],
    temperature: 0,
  });

  const content = completion.choices?.[0]?.message?.content ?? '';
  return content;
}
